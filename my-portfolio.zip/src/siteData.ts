export const projects = [
  {
    slug: 'beacon',
    name: 'Beacon',
    tagline: 'Service runner & scheduler for desktop',
    description: 'Start/stop services, autostart, simple scheduler. Built with Tauri + React.',
    stack: ['Tauri', 'React', 'Go'],
    links: [
      { label: 'Website', href: 'https://example.com' },
      { label: 'GitHub', href: 'https://github.com/you/beacon' },
    ],
  },
  {
    slug: 'onlylink',
    name: 'OnlyLink',
    tagline: 'Whitelist-based Android browser',
    description: 'Distraction-free browsing with schedules and blockers.',
    stack: ['Kotlin', 'Compose'],
    links: [{ label: 'Play Store', href: '#' }],
  },
  {
    slug: 'proxydoc',
    name: 'ProxyDoc',
    tagline: 'API docs via reverse-proxy capture',
    description: 'Generate neutral JSON spec, OpenAPI 3.1, Postman v2.1 from live traffic.',
    stack: ['Go', 'Proxy'],
    links: [{ label: 'GitHub', href: '#' }],
  },
]
