import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Projects from './pages/Projects'
import Contact from './pages/Contact'

export default function App() {
  return (
    <div className="app">
      <div className="blurred-orb blurred-orb--cyan" />
      <div className="blurred-orb blurred-orb--violet" />

      <header className="nav">
        <Link to="/" className="nav-brand">
          <span className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-sm font-semibold text-sky-100">
            JM
          </span>
          <div className="flex flex-col leading-none">
            <strong className="text-xs text-slate-100">Julian Mindria</strong>
            <span>Mindria Labs</span>
          </div>
        </Link>

        <nav className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/projects">Projects</Link>
          <Link to="/contact">Contact</Link>
          <a
            href="https://github.com/<username>"
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center gap-2 rounded-full border border-white/10 px-5 py-2 text-[11px] font-semibold tracking-[0.18em] uppercase text-slate-200 transition-colors hover:border-[var(--brand)] hover:text-[#e0f2fe]"
          >
            GitHub
          </a>
        </nav>
      </header>

      <main className="main-content">
        <div className="container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </div>
      </main>

      <footer className="footer">
        Crafted with curiosity | {new Date().getFullYear()} Julian Mindria | Mindria Labs
      </footer>
    </div>
  )
}