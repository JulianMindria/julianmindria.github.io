import { projects } from '../siteData'
import { useSearchParams } from 'react-router-dom'

export default function Projects() {
  const [searchParams] = useSearchParams()
  const focus = searchParams.get('focus')

  return (
    <section className="space-y-12">
      <header className="space-y-4">
        <span className="section-label">Build Log</span>
        <h1 className="text-4xl font-semibold tracking-tight text-[var(--fg)]">Projects crafted with intent</h1>
        <p className="max-w-2xl text-sm text-[var(--muted)]">
          A curated mix of experiments, production apps, and productized tooling. Filter via the hash focus parameter to jump straight into a project.
        </p>
      </header>

      <div className="grid">
        {projects.map(project => {
          const isFocused = focus === project.slug

          return (
            <article
              key={project.slug}
              id={project.slug}
              className={[
                'card group transition-all duration-200',
                isFocused && 'ring',
              ]
                .filter(Boolean)
                .join(' ')}
            >
              <div className="flex items-start justify-between gap-4">
                <h3 className="text-xl font-semibold text-[var(--fg)]">{project.name}</h3>
                <span className="rounded-full border border-white/10 px-3 py-1 text-[11px] uppercase tracking-[0.16em] text-slate-300">
                  {project.type ?? 'Build'}
                </span>
              </div>

              <p className="text-[var(--muted)]">{project.description}</p>
              <p className="muted text-sm uppercase tracking-[0.18em] text-slate-300">{project.stack.join(' | ')}</p>

              {project.links?.length ? (
                <div className="mt-4 flex flex-wrap gap-3">
                  {project.links.map(link => (
                    <a
                      key={link.href}
                      href={link.href}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="cta-secondary gap-2 text-xs"
                    >
                      {link.label}
                    </a>
                  ))}
                </div>
              ) : null}
            </article>
          )
        })}
      </div>
    </section>
  )
}
