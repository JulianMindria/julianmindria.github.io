import { Link } from 'react-router-dom'
import { projects } from '../siteData'

export default function Home() {
  const featured = projects.slice(0, 3)

  return (
    <section className="space-y-16">
      <div className="surface relative overflow-hidden">
        <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-[rgba(56,189,248,0.2)] blur-3xl" aria-hidden />
        <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-[rgba(99,102,241,0.22)] blur-3xl" aria-hidden />

        <span className="section-label">Mindria Labs</span>
        <h1 className="mt-6 max-w-2xl text-5xl font-semibold leading-tight tracking-tight text-[var(--fg)] md:text-6xl">
          Building digital products with a <span className="text-gradient">maker mindset</span>.
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-[var(--muted)]">
          Hi, I am Julian - a software engineer who turns raw ideas into polished, high-impact products.
          I specialize in shipping performant cross-platform experiences powered by pragmatic engineering.
        </p>

        <div className="mt-10 flex flex-wrap gap-4">
          <Link to="/projects" className="cta-primary">
            Explore Projects
          </Link>
          <Link to="/contact" className="cta-secondary">
            Collaborate
          </Link>
        </div>

        <ul className="badges mt-10">
          <li>Go</li>
          <li>Laravel</li>
          <li>React</li>
          <li>Kotlin</li>
          <li>Tauri</li>
          <li>Product Design</li>
        </ul>
      </div>

      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-2">
            <span className="section-label">Featured Projects</span>
            <h2 className="text-3xl font-semibold tracking-tight text-[var(--fg)]">Recent Launches</h2>
            <p className="max-w-xl text-sm text-[var(--muted)]">
              Selected builds that blend delightful UX with resilient architecture.
            </p>
          </div>
          <Link to="/projects" className="cta-secondary">
            View all work
          </Link>
        </div>

        <div className="grid">
          {featured.map(project => (
            <a key={project.slug} className="card group" href={`#/projects?focus=${project.slug}`}>
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-[var(--fg)]">{project.name}</h3>
                <span className="text-xs uppercase tracking-[0.2em] text-sky-200 transition-transform duration-200 group-hover:translate-x-1">
                  Open -&gt;
                </span>
              </div>
              <p className="text-[var(--muted)]">{project.tagline}</p>
              <span className="text-sm text-[var(--muted)]">{project.stack.join(' | ')}</span>
            </a>
          ))}
        </div>
      </div>

      <div className="surface grid gap-6 md:grid-cols-3">
        <div>
          <h3 className="text-gradient text-3xl font-semibold">2+ yrs</h3>
          <p className="mt-2 text-sm text-[var(--muted)]">Hands-on experience shipping production-grade apps and tooling.</p>
        </div>
        <div>
          <h3 className="text-gradient text-3xl font-semibold">Multi-stack</h3>
          <p className="mt-2 text-sm text-[var(--muted)]">From embedded schedulers to mobile browsers - picking the right stack for the job.</p>
        </div>
        <div>
          <h3 className="text-gradient text-3xl font-semibold">From 0 -&gt; 1</h3>
          <p className="mt-2 text-sm text-[var(--muted)]">Partnering with founders to ideate, prototype, iterate, and launch mindfully.</p>
        </div>
      </div>
    </section>
  )
}
