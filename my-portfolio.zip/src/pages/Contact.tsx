export default function Contact() {
  return (
    <section className="space-y-10">
      <div className="surface space-y-6">
        <span className="section-label">Get in touch</span>
        <h1 className="text-4xl font-semibold tracking-tight text-[var(--fg)]">Let us build something meaningful</h1>
        <p className="text-[var(--muted)]">
          Whether you are validating an idea, need a technical partner, or want to level up an existing product � I am excited to collaborate.
          Drop a note and I will reply within a day.
        </p>
        <div className="flex flex-wrap items-center gap-4 text-sm text-[var(--muted)]">
          <a className="cta-primary" href="mailto:hello@mindria.dev">Email Julian</a>
          <a
            className="cta-secondary"
            href="https://www.linkedin.com/in/<username>"
            target="_blank"
            rel="noreferrer noopener"
          >
            LinkedIn profile
          </a>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="card">
          <h2 className="text-xl font-semibold text-[var(--fg)]">Availability</h2>
          <p className="text-sm text-[var(--muted)]">
            Currently accepting new product engagements for Q4. Fractional engineering, prototyping sprints, or end-to-end builds.
          </p>
        </div>
        <div className="card">
          <h2 className="text-xl font-semibold text-[var(--fg)]">Preferred channels</h2>
          <p className="text-sm text-[var(--muted)]">
            Email for project briefs, LinkedIn for networking, and GitHub for code + open-source initiatives.
          </p>
        </div>
      </div>
    </section>
  )
}